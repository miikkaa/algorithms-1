import edu.princeton.cs.algs4.WeightedQuickUnionUF;

/** Percolation, API in accordance to the assignment. */
public class Percolation {

  private final int n;
  private final boolean[][] openSites;
  private int noOfOpenSites = 0;
  private final WeightedQuickUnionUF data;

  // creates n-by-n grid, with all sites initially blocked
  public Percolation(final int n) {
    if (n <= 0) {
      throw new IllegalArgumentException();
    }
    this.n = n;
    this.openSites = new boolean[n][n];
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < n; j++) {
        openSites[i][j] = false;
      }
    }
    this.data = new WeightedQuickUnionUF(n * n + 2);
  }

  private void validate(int row, int col) {
    if (row <= 0 || row > n || col <= 0 || col > n) {
      throw new IllegalArgumentException();
    }
  }

  // opens the site (row, col) if it is not open already
  public void open(int row, int col) {
    validate(row, col);

    if (isOpen(row, col)) {
      return;
    }

    int site = getIndex(row, col);
    openSites[row - 1][col - 1] = true;
    noOfOpenSites++;

    // connect up
    if (row > 1 && isOpen(row - 1, col)) {
      data.union(getIndex(row - 1, col), site);
    } else if (row == 1) {
      // connect first row to the virtual top
      data.union(0, site);
    }

    // connect down
    if (row < n && isOpen(row + 1, col)) {
      data.union(getIndex(row + 1, col), site);
    } else if (row == n) {
      // connect last row to the virtual bottom
      data.union(n * n + 1, site);
    }

    // connect left
    if (col > 1 && isOpen(row, col - 1)) {
      data.union(getIndex(row, col - 1), site);
    }

    // connect right
    if (col < n && isOpen(row, col + 1)) {
      data.union(getIndex(row, col + 1), site);
    }
  }

  private int getIndex(int row, int col) {
    validate(row, col);
    return (row - 1) * n + (col - 1) + 1; // account for the virtual top
  }

  // is the site (row, col) open?
  public boolean isOpen(int row, int col) {
    validate(row, col);
    return openSites[row - 1][col - 1];
  }

  // is the site (row, col) full?
  public boolean isFull(int row, int col) {
    validate(row, col);
    int site = getIndex(row, col);
    return data.find(0) == data.find(site);
  }

  // returns the number of open sites
  public int numberOfOpenSites() {
    return noOfOpenSites;
  }

  // does the system percolate?
  public boolean percolates() {
    return data.find(n * n + 1) == data.find(0);
  }
}
